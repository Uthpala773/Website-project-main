# Website-project
This is a website project that was built using JavaScript.

## Technologies Used
 - HTML
 - CSS
 - JavaScript

## Installation
1. Clone the repository
 
   https://github.com/amrAbir/website-project.git
   
2. Open the index.html file in your browser.

## Site Preview
![](https://github.com/amrAbir/Website-project/blob/main/preview.png)
